# Local settings for DMOJ

import os
from django.utils.translation import gettext_lazy as _

# Base directory
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'change_me_to_a_random_string_please'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True
ALLOWED_HOSTS = ['*']

# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'dmoj',
        'USER': 'dmoj',
        'PASSWORD': 'dmojpass',
        'HOST': 'db',
        'PORT': '3306',
        'OPTIONS': {
            'charset': 'utf8mb4',
            'sql_mode': 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION',
        },
    }
}

# Bridged configuration
BRIDGED_JUDGE_ADDRESS = [('localhost', 9999)]
BRIDGED_DJANGO_ADDRESS = [('localhost', 9998)]
BRIDGED_DJANGO_CONNECT = None

# Cache configuration
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': 'redis://redis:6379/1',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
        }
    }
}

# Event server
EVENT_DAEMON_USE = True
EVENT_DAEMON_POST = 'ws://wsevent:15101/'
EVENT_DAEMON_GET = 'ws://wsevent:15102/'
EVENT_DAEMON_POLL = '/etc/event-server-poll/'
EVENT_DAEMON_KEY = None

# Redis
REDIS_CONNECTION = ('redis', 6379)

# Email configuration
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# Static files
STATIC_ROOT = os.path.join(BASE_DIR, 'static')
STATIC_URL = '/static/'

# Media files
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
MEDIA_URL = '/media/'

# Celery configuration
CELERY_BROKER_URL = 'redis://redis:6379/0'
CELERY_RESULT_BACKEND = 'redis://redis:6379/0'

# Site
SITE_NAME = _('DMOJ')
SITE_LONG_NAME = _('DMOJ: Modern Online Judge')

# Problem data storage
DMOJ_PROBLEM_DATA_ROOT = '/problems/'

# PDF rendering
DMOJ_PDF_PROBLEM_CACHE = os.path.join(DMOJ_PROBLEM_DATA_ROOT, 'pdf')
DMOJ_PDF_PROBLEM_TEMP_DIR = os.path.join(DMOJ_PROBLEM_DATA_ROOT, 'tmp')

# User-friendly captcha
HCAPTCHA_SITEKEY = None
HCAPTCHA_SECRET = None

# Google OAuth
OAUTH2_PROVIDER = None

# Social authentication
SOCIAL_AUTH_GOOGLE_OAUTH2_KEY = None
SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET = None

# Allow users to download their data
DMOJ_USER_DATA_DOWNLOAD = True
DMOJ_USER_DATA_CACHE = os.path.join(DMOJ_PROBLEM_DATA_ROOT, 'user-data-cache')
DMOJ_USER_DATA_INTERNAL = os.path.join(DMOJ_PROBLEM_DATA_ROOT, 'user-data-internal')

# VNOJ-specific settings
VNOJ_TESTCASE_HARD_LIMIT = 100
VNOJ_TESTCASE_SOFT_LIMIT = 50
VNOJ_LONG_QUEUE_ALERT_THRESHOLD = 10 